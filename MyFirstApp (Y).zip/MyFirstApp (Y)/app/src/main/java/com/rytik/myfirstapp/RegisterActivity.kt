package com.rytik.myfirstapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val mButton =findViewById<TextView>(R.id.nomer)
        val kButton =findViewById<TextView>(R.id.email)
        val stroka =findViewById<EditText>(R.id.inputEmail)
        val register =findViewById<Button>(R.id.btnRegister)
        val pass1 =findViewById<EditText>(R.id.inputPassword)
        val pass2 =findViewById<EditText>(R.id.inputConformPassword)

        kButton.setOnClickListener {
            kButton.setTextColor(resources.getColor(R.color.purple_700))
            mButton.setTextColor(resources.getColor(R.color.white))
            stroka.hint="Введите email"
            stroka.inputType=InputType.TYPE_CLASS_TEXT

        }
        mButton.setOnClickListener {
            mButton.setTextColor(resources.getColor(R.color.purple_700))
            kButton.setTextColor(resources.getColor(R.color.white))
            stroka.hint="Введите номер"
            stroka.inputType=InputType.TYPE_CLASS_NUMBER
        }
        register.setOnClickListener {
            val myText = stroka.text.toString()
            if (!myText.contains("@") && stroka.inputType == InputType.TYPE_CLASS_TEXT){
                Toast.makeText(this,"Введен неверный email",Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (!myText.contains("+") && stroka.inputType == InputType.TYPE_CLASS_NUMBER) {
                Toast.makeText(this, "Введен неверный номер телефона", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val myText2 = pass1.text.toString()
            if (myText2.length < 8) {
                Toast.makeText(
                    this,
                    "Пароль должен содержать минимум 8 символов",
                    Toast.LENGTH_LONG
                ).show()
                return@setOnClickListener
            }
            val myText3 = pass2.text.toString()
            if (myText2 != myText3) {
                Toast.makeText(this, "Пароли не совпадают!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }


        }

    }
}